create table cliente
cod_cli int not null auto_increment,
tel varchar(15) not null,
cel varchar(15) not null,
email varchar(150) not null,
senha varchar(15) not null,
login varchar(15) not null,
nome varchar(80) not null,
primary key(cod_cli)
);
